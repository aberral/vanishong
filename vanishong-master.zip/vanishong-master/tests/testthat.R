library(testthat)
library(vanishong)

test_check("vanishong")
